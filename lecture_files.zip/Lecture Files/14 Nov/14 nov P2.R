#Logistic Reg on carseats dataset

setwd("E:/RetailAnalytics")
getwd()